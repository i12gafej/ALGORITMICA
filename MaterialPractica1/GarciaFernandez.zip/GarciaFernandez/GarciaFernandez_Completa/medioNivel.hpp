#include "apartado1.hpp"
#include "apartado2.hpp"
#include "apartado3.hpp"

void ordenacionSeleccion();
void cuadradoMatriz();
void fibonacciRecursivo();