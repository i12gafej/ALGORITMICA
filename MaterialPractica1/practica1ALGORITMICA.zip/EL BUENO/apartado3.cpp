#include "apartado3.hpp"

double fibonacci(double n){
    if(n <= 2)
        return (n-1);
    else
        return fibonacci(n-1)+fibonacci(n-2);
}
void tiemposFibonacci(int nMin, int nMax, std::vector <double> &tiemposReales, std::vector <double> &numeroElementos){
    Clock time;
    double aux = 0;
    int count = 0;
    for(double i = nMin; i < nMax; i++){
        numeroElementos.push_back(i);
        //std::cout<<"N = "<<i<<"."<<std::endl;
        time.start();
        fibonacci(i);
        time.stop();
        //std::cout<<"Tiempos reales [ "<<i<<"] --> "<<time.elapsed()<<std::endl;
        tiemposReales.push_back(time.elapsed());
        //std::cout<<"ANIADIDO [ "<<i<<"] --> "<<tiemposReales[count]<<std::endl;
        count++;        
    }
}
void ajusteExponencial(const std::vector <double> &n, const std::vector <double> &tiemposReales, std::vector <double> &a){
    int grado = 2;
    std::vector<std::vector<double>> A = std::vector<std::vector<double>>(grado, std::vector<double>(grado));
    std::vector<std::vector<double>> B = std::vector<std::vector<double>>(grado, std::vector<double>(1));
    std::vector<std::vector<double>> X = std::vector<std::vector<double>>(grado, std::vector<double>(grado));

    for(int i = 0; i < grado; i++) {
        //for(int j = 0; j < 1; j++){
            B[i][0] = sumatorio(n,tiemposReales,i,1);
            //std::cout<<sumatorio(n,tiemposReales,i,1)<< " // ";
       // }
        
    }
    for(int i = 0; i < grado;i++){
        for(int j = 0; j < grado;j++){
            //si fila es 0, 0,0 es a elevado a 0, si es 1, ...            
                A[i][j] = sumatorio(n,tiemposReales,i+j, 0);
                A[j][i] = sumatorio(n,tiemposReales,i+j, 0);                
            //std::cout<<sumatorio(n,tiemposReales,i+j,0)<< " // ";
            
        }
    }

    /*std::cout<<std::endl;
    std::cout<<"MATRIZ A"<<std::endl;
    for(int i = 0; i < A.size(); i++){
        for(int j = 0; j < A[i].size(); j++){
            std::cout<<A[i][j]<<"  ";
        }
        std::cout<<std::endl;
    }
    std::cout<<"MATRIZ B"<<std::endl;
    for(int i = 0; i < B.size(); i++){
        for(int j = 0; j < B[i].size(); j++){
            std::cout<<B[i][j]<<"  ";
        }
        std::cout<<std::endl;
    }*/
    
    resolverSistemaEcuaciones(A,B,grado,X);

    std::cout<<"MATRIZ X"<<std::endl;
    for(int i = 0; i < X.size(); i++){
        for(int j = 0; j < X[i].size(); j++){
            std::cout<<X[i][j]<<"  ";
        }
        std::cout<<std::endl;
    }

    a.push_back(X[0][0]);
    a.push_back(X[1][0]);
}
void calcularTiemposEstimadosExponencial(const std::vector <double> &n, const std::vector <double> &tiemposReales, const std::vector <double> &a, std::vector <double> &tiemposEstimados){
    for(int i = 0; i < n.size(); i++){
        //std::cout<<"Tiempos ["<<i<<"] = "<<a[0]+a[1]*pow(2,n[i])<<std::endl;
        tiemposEstimados.push_back(a[0]+a[1]*pow(2,n[i]));
    }
}
double calcularTiempoEstimadoExponencial(const double &n, const vector <double> &a){
    return a[0] + a[1]*pow(2, n);
}
void 
cambioVariable(const std::vector<double> &n, std::vector<double> &z){
    for(int i = 0; i < n.size(); i++){
        z.push_back(pow(2, n[i]));
        //std::cout<<"Z["<<i<<"]: "<<pow(2, n[i])<<std::endl;
    }
}