#ifndef VEGAS_HPP
#define VEGAS_HPP

#include <vector>
using namespace std;

int repetir(int n, vector<int>&x);
bool nReinasLasVegas( int n, vector<int >&solucion);
void escribirSolucion( vector<int>&solucion);
bool lugar(int k, vector<int>&x);

#endif