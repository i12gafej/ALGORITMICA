#include "funcionesBasicas.hpp"

void
rellenarVector(vector<int> &v1, vector<int> &v2){
    srand(time(nullptr));
    int a = 0;
    for(int i = 0; i < v1.size(); i++){
        a = rand() % 10000000;
        v1[i] = a;
        v2[i] = a;
    }
}

void imprimir(vector <double> qs1, vector <double> qs2, vector <int> n){
    ofstream f;
    f.open("tiempos.txt", ios::out);

    if(!f.is_open()){
        cout << "Error al abrir fichero" << endl;
        return;
    }

    for(int i = 0; i < n.size(); i++){
        f << n[i] << " " <<qs1[i] << " "<<qs2[i]<<endl;
    }
    f.close();

}

