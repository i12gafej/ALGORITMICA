#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

void
rellenarVector(vector<int> &v1, vector<int> &v2);
void
imprimir(vector <double> qs1, vector <double> qs2, vector <int> n);
