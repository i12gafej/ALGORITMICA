#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

void
rellenarVector(vector<double> &v1, vector<double> &v2);
void
imprimir(vector <double> qs1, vector <double> qs2, vector <int> n);
