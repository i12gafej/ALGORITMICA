#include "funcionesBasicas.hpp"
#include "quicksort.hpp"

void 
comparacionVariantesQuicksort(int nMin, int nMax, int incremento, int repeticiones, int nMediana, int nElementosMinimo);
